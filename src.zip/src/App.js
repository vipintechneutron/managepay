import './App.css';
import Employee from './Components/Employee';

function App() {
  return (
    <div className="App">   
       <Employee/>
    
    </div>
  );
}

export default App;
