import React from "react";
function Details(){
    return(
        <>

        </>
    )
}

export default Details