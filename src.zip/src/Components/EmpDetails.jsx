import React, { useEffect, useState } from "react";
import '../Css/EmpDetails.css'
import axios from 'axios'
const EmpDetails = ({ Details }) => {
    const [leaves,setLeaves]=useState(0)
    const handleTransections=()=>{
        let transection_object={...Details[0][0]}

        transection_object.UnpaidLeaves=leaves
        console.log(transection_object);
        axios.post("http://localhost/server.php",transection_object).then((res)=>{
             console.log(res);
        }).catch((err)=>{
                console.log("err",err);
        })
    }

     const handleUnpaidleaves=(e)=>{
        console.log(e.target.value);
       setLeaves(e.target.value)
     }
    console.log("lighikhglhoil",Details[0][0]);
    return (
        <div className="emp-table">
            <div>
            <table border={1}>
                <tbody>
                    {Details[0].map((info, index) => {
                        return <tr key={index} className="Emp">

                            <tr >
                                <th style={{width:"200px",textAlign:'center'}}>Employee ID</th>
                                <td style={{width:"200px"}} className="td_Table">{info.EmployeeId}</td>
                            </tr>
                            <tr className="tr_table">
                                <th>First Name</th>
                                <td className="td_Table">{info.FirstName}</td>
                            </tr>

                            <tr lassName="tr_table">
                                <th>Last Name</th>
                                <td className="td_Table">{info.LastName}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Date of Birth</th>
                                <td className="td_Table">{info.Date_of_birth}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Join Date</th>
                                <td className="td_Table">{info.Join_Date}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Hire Date</th>
                                <td className="td_Table">{info.Hire_Date}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Email</th>
                                <td className="td_Table">
                                    {info.Email}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Phone</th>
                                <td className="td_Table"> {info.Phone}</td>
                            </tr>

                            <tr lassName="tr_table">
                                <th>Country</th> <td className="td_Table"> {info.Country}</td>
                            </tr>

                            <tr lassName="tr_table">
                                <th>Position</th><td className="td_Table">{info.Position}</td>
                            </tr>

                            <tr lassName="tr_table">
                                <th>Department</th>
                                <td className="td_Table">{info.Department}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Salary</th>
                                <td className="td_Table">{info.Salary}</td>
                            </tr>
                            <tr lassName="tr_table">
                                <th>Total Paid Leaves</th>
                                <td className="td_Table">{info.Total_Paid_leaves}</td>
                            </tr>
                             <tr lassName="tr_table">
                                <th>Total Unpaid leave</th>
                                <td className="td_Table"><input type="number" placeholder="Enter unpaid leaves" className="input_" onChange={handleUnpaidleaves}/></td>
                             </tr>


                        </tr>
                    })}
                </tbody>
            </table>
            </div>
             <div>
             <h1>Hi,{Details[0].map((item, index) => <span>{item.FirstName}</span>)}</h1>
                <button onClick={handleTransections} >Genrate transaction</button>
             </div>
          
        </div>

    )
}

export default EmpDetails