import React, { useEffect, useState } from "react";
import axios from 'axios'
import '../Css/Employee.css'
import EmpDetails from "./EmpDetails";
import Dialog from "./Dialog";
const Employee = () => {
    const [Data, setData] = useState([])
    const [Details, setDetails] = useState()
    const [Boolean, setBoolean] = useState(false)
    useEffect(() => {
        axios.get("http://localhost/server.php").then((res) => {
            setData(res.data)
        }).catch((err) => {
            console.log("there are some error", err);
        })
    }, [])

    const handleView = (EmployeeId) => {
        console.log(EmployeeId);
        Data.filter((item, index) => {
            if (item.EmployeeId == EmployeeId) {
                setDetails([item])
                setBoolean(!Boolean)
            }

        })
    }
    console.log(Data);
    console.log(Details);

    return (
        <>
            <h1>Welcome To ManagePay</h1>
            {/* {Boolean && <Dialog details={[Details]} />} */}
            <table border={1} className="App-header ">
                <thead>
                    <th>Employee ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Date of Birth</th>
                    <th>Join Date</th>
                    <th>Hire Date</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Country</th>
                    <th>Position</th>
                    <th>Department</th>
                    <th>Salary</th>
                    <th>Total Paid Leaves</th>
                    <th>Details</th>
                </thead>
                <tbody>
                    {Data.map((info, index) => {
                        return <tr key={index}><td>{info.EmployeeId}</td><td>{info.FirstName}</td><td>{info.LastName}</td><td>{info.Date_of_birth}</td><td>{info.Join_Date}</td><td>{info.Hire_Date}</td><td>{info.Email}</td><td>{info.Phone}</td><td>{info.Country}</td><td>{info.Position}</td><td>{info.Department}</td><td>{info.Salary}</td><td>{info.Total_Paid_leaves}</td><td><button onClick={() => handleView(info.EmployeeId)}>View</button></td></tr>
                    })}
                </tbody>
            </table>
            <div>

                {/* { Boolean && <EmpDetails details={[Details]}/> } */}
                { Boolean && <Dialog details={[Details]} setBoolean={setBoolean} Boolean={Boolean}/> }
                
            </div>



        </>

    )

}
export default Employee
