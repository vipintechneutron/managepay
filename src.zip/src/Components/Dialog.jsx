import React, { useState } from 'react';
import '../Css/dialog.css'
import EmpDetails from './EmpDetails';
const Dialog = ({ details, setBoolean, Boolean }) => {
    const [isDialogOpen, setIsDialogOpen] = useState(true);

    const openDialog = () => {
        setIsDialogOpen(true);
    };

    const closeDialog = () => {
        setIsDialogOpen(false);
        setBoolean(!Boolean)
        
    };
    return (

        <div>

            <div className="dialog-overlay">
                <div className="dialog">
                    <button onClick={closeDialog}>
                        Close
                    </button>
                    <EmpDetails Details={details} />
                
                </div>
         
            </div>
           

        </div>
    );
}

export default Dialog;